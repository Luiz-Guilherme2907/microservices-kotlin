package com.guilherme

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CambioServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
